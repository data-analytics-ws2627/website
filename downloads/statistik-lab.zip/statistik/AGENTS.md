# Regeln für das Statistik-Labor

- Originaldaten unverändert lassen. Bereinigte Daten in eigenen Dateien speichern.
- Nur den beauftragten Analyseschritt bearbeiten. Vorhandene Ergebnisse erhalten.
- Beobachtungseinheit, Auswahl, Zähler, Nenner und Einheiten ausdrücklich prüfen.
- Code mit der vorhandenen uv-Umgebung ausführen. Keine neuen Abhängigkeiten ohne Auftrag.
- Berechnete Ergebnisse von Annahmen unterscheiden. Fehlende Daten nicht erfinden.
- Dateiänderungen und Prüfergebnisse nachvollziehbar berichten.
- Keine Daten hochladen oder veröffentlichen, sofern dies nicht ausdrücklich beauftragt ist.
